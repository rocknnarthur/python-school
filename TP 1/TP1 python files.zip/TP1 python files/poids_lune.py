g = 1.6
m = int(input("Saisir la masse m (en kg): "))
P = g*m
print(f"Le poids sur la lune est de {P} kg")