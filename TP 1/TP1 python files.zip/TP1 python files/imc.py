m = int(input("Saisir la masse m (en kg): "))
t = float(input("Saisir la taille t (en mètres): "))
imc = m/(t**2)
print(f"Votre IMC est de {imc}")