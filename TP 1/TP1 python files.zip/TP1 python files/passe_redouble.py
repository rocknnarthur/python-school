l = []
for note in range(1, 4):
    n = float(input(f"Saisissez votre note {note}: "))
    l.append(n)

a = 0
if l[0] + l[1] + l[2] >= 30:
    print("Année validée")

elif l[0] < 8:
    a = 10-l[0]
    print(f"Vous redoublez, {a}")

elif l[1] < 8:
    a = 10-l[1]
    print(f"Vous redoublez, {a}")
    
elif l[2] < 8:
    a = 10-l[2]
    print(f"Vous redoublez, {a}")
    
elif (l[0] + l[1] + l[2])/3 >= 10:
    print("Année validée")
    
else:
    a = (10-l[0])+(10-l[1])+(10-l[2])
    print(f"Vous redoublez, {a}")