word = input("Ecrivez un mot: ")
e = 0
for letter in word:
    if letter == "e":
        e += 1

print(f"Il y a {e} E dans votre mot")
        